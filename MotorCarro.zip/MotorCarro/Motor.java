// Motor.java
public class Motor {
    private String modelo;

    public Motor(String modelo) {
        this.modelo = modelo;
    }

    public String getModelo() {
        return modelo;
    }

    public void funcionar() {
        System.out.println("O motor " + modelo + " está funcionando.");
    }
}
