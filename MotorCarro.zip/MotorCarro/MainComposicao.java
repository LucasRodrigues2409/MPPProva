// MainComposicao.java
import java.util.Scanner;

public class MainComposicao {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o modelo do motor do carro: ");
        String modeloMotor = scanner.nextLine(); // Solicita o modelo do motor ao usuário

        // Criando um Carro com o Motor especificado pelo usuário
        Carro carro = new Carro(modeloMotor);
        carro.ligarCarro(); // Liga o carro, que também liga o motor
        
        scanner.close();
    }
}
