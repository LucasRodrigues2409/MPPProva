// Carro.java
public class Carro {
    private Motor motor; // Composição: O Carro tem um Motor

    public Carro(String modeloMotor) {
        // Ao criar um Carro, um Motor é automaticamente criado
        this.motor = new Motor(modeloMotor); // O Motor é uma parte essencial do Carro
    }

    public void ligarCarro() {
        System.out.println("O carro está ligado.");
        motor.funcionar(); // Chamando o método do Motor que está contido no Carro
    }
}
